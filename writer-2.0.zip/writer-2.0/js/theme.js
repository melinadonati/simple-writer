//////////////////////////////////////////
//
//				THEME
//
//////////////////////////////////////////

var themeWindow = "<button class=\"button\" onclick=\"loadBGdialog();removeWindow($(this));\">BACKGROUND</button> <button class=\"button\" onclick=\"loadStyleDialog();removeWindow($(this));\">STYLE</button>";

//////////////////////////////////////////
//
//				COLORS
//
//////////////////////////////////////////

var styleWindow = "<label for=\"cssurl\">URL:</label> <input type=\"text\" id=\"cssurl\" name=\"cssurl\"><button class=\"button\" type=\"button\" onclick=\"previewStyle('cssurl');\">Ok</button><br><br><div id=\"dropbox\">Load an URL or drop a CSS file here</div>";

//-- Opens dialog for Background --//
function loadStyleDialog() {
	modal('styleWindow',styleWindow,'Style');
	$(".content").append("<br><br>");
	// Drag & Drop CSS file //
	var dropbox = document.getElementById("dropbox");
	// Event handlers //
	dropbox.addEventListener("dragenter", dragEvent, false);
	dropbox.addEventListener("dragexit", dragEvent, false);
	dropbox.addEventListener("dragover", dragEvent, false);
	dropbox.addEventListener("drop", dropStyle, false);
}

function previewStyle(id) {
	id = "#"+id;
	val = $(id).val();
	var link = "<link href=\""+val+"\" media=\"screen\" rel=\"stylesheet\"></link>";
	$("head").append(link);
	$("#saveStyle").remove();
	$(".content").append("<button id='saveStyle' class='button' type='button' onclick='changeStyle(\""+val+"\");'>Save</button>");
}

function changeStyle(href) {
	var link = "<link href=\""+href+"\" media=\"screen\" rel=\"stylesheet\"></link>";
	if(typeof(Storage)!=="undefined") {
		localStorage.setItem("theme",link);
	}
}

//////////////////////////////////////////
//
//				BACKGROUND
//
//////////////////////////////////////////

//-- Dialog content for Background --//
var bgHTML = "<button class=\"button\" onclick=\"styleBG('image')\">IMAGE</button> <button class=\"button\" onclick=\"styleBG('pattern')\">PATTERN</button><br><br><label for=\"imgurl\">URL:</label> <input type=\"text\" id=\"imgurl\" name=\"imgurl\"><button class=\"button\" type=\"button\" onclick=\"previewBG('imgurl');\">Ok</button><br><br><div id=\"dropbox\">Load an URL or drop a file here</div>";

//-- Opens dialog for Background --//
function loadBGdialog() {
	modal('styleWindow',bgHTML,'Background');
	$(".content").append("<br><br>");
	// Drag & Drop BG image //
	var dropbox = document.getElementById("dropbox");
	// Event handlers //
	dropbox.addEventListener("dragenter", dragEvent, false);
	dropbox.addEventListener("dragexit", dragEvent, false);
	dropbox.addEventListener("dragover", dragEvent, false);
	dropbox.addEventListener("drop", dropBG, false);
}

//-- Preview chosen image --//
function previewBG(id) {
	id = "#"+id;
	val = $(id).val();
	$("#dropbox").css("padding","1px");
	$("#dropbox").html("<img src='"+val+"' alt='Background preview'>");
	$("#saveBG").remove();
	$(".content").append("<button id='saveBG' class='button' type='button' onclick='changeBG();'>Save</button>");
}

//-- Change page background --//
function changeBG() {
	var src = $("#dropbox img").attr("src");
	url = "url('"+src+"')";
	if(typeof(Storage)!=="undefined") {
		localStorage.setItem("background",url);
	}
	$("body").css("background-image",url);
	toggle('overlay');
}

//-- Change background style --//
function styleBG(style) {

	// An image covers the background //
	if(style=="image") {
		localStorage.setItem("background.style",JSON.stringify({"background-repeat":"no-repeat","background-position":"inherit","background-size":"cover"}));
		$("body").css({"background-repeat":"no-repeat","background-position":"inherit","background-size":"cover"});

	// A pattern fills it //
	} else if(style=="pattern") {
		localStorage.setItem("background.style",JSON.stringify({"background-repeat":"repeat","background-position":"top top","background-size":"inherit"}));
		$("body").css({"background-repeat":"repeat","background-position":"top top","background-size":"inherit"});
	}
}
