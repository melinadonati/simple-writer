//////////////////////////////////////////
//
//				SOUNDS
//
//////////////////////////////////////////


//************* Typewriter sounds *************//

var ding = new buzz.sound("js/sounds/ding.wav");
var type = new buzz.sound("js/sounds/type.wav");

//*********** Alphabet sounds ***********//
var sounds = {};
var letters = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"];

letters.forEach(function(letter, index, letters){
	sounds[letter] = new buzz.sound("js/sounds/"+letter+".wav");
});


//////////////////////////////////////////
//
//				READY
//
//////////////////////////////////////////

$(document).ready(function(){

	//////////////////////////////////////////
	//				THEME INIT
	//////////////////////////////////////////

	if(typeof(Storage)!=="undefined") {

		$("head").append( localStorage.getItem("theme") );
		$("body").css( "background-image",localStorage.getItem("background") );
		$("body").css( JSON.parse(localStorage.getItem("background.style")) );
	}

	//////////////////////////////////////////
	//				SOUND EVENTS
	//////////////////////////////////////////

	$("body").keypress(function(event){
		var keycode = (event.keyCode ? event.keyCode : event.which);

		console.log(keycode);

		switch(keycode){

			// ENTER //
			case 13: ding.stop().play();
			break;

			// ALPHABET //
			case 97: sounds.a.stop().play();
			break;
			case 98: sounds.b.stop().play();
			break;
			case 99: sounds.c.stop().play();
			break;
			case 100: sounds.d.stop().play();
			break;
			case 101: sounds.e.stop().play();
			break;
			case 102: sounds.f.stop().play();
			break;
			case 103: sounds.g.stop().play();
			break;
			case 104: sounds.h.stop().play();
			break;
			case 105: sounds.i.stop().play();
			break;
			case 106: sounds.j.stop().play();
			break;
			case 107: sounds.k.stop().play();
			break;
			case 108: sounds.l.stop().play();
			break;
			case 109: sounds.m.stop().play();
			break;
			case 110: sounds.n.stop().play();
			break;
			case 111: sounds.o.stop().play();
			break;
			case 112: sounds.p.stop().play();
			break;
			case 113: sounds.q.stop().play();
			break;
			case 114: sounds.r.stop().play();
			break;
			case 115: sounds.s.stop().play();
			break;
			case 116: sounds.t.stop().play();
			break;
			case 117: sounds.u.stop().play();
			break;
			case 118: sounds.v.stop().play();
			break;
			case 119: sounds.w.stop().play();
			break;
			case 120: sounds.x.stop().play();
			break;
			case 121: sounds.y.stop().play();
			break;
			case 122: sounds.z.stop().play();
			break;

			// ANY //
			default: type.stop().play();
			break;
		}
	});

});
