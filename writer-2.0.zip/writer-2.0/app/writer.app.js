"use strict";

/////////////////////////////////////
//  Debug tool
/////////////////////////////////////
var debug = false;
function log(something,before,after) {
  if(debug) {
    (before) ? console.log(before) : "";
    console.log(something);
    (after) ? console.log(after) : "";
  }
}

/////////////////////////////////////
//  Application
/////////////////////////////////////
(function(){

  angular.module('writer', []);

  // Set to true for debugging
  debug = true;

})();
