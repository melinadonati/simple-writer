(function(){
  "use strict";

  angular.module('writer').controller('writerCtrl', writerCtrl);
  writerCtrl.$inject = ["$rootScope","$scope","modalService","storageService"];

    /////////////////////////////////////
   //  Controller
  /////////////////////////////////////
  function writerCtrl($rootScope,$scope,modalService,storageService) {
    var vm = this;

    // Onscreen text
    vm.current = {};
    vm.fileslist = [];

    vm.message = {};
    vm.message.type = "info";
    vm.message.content = "Your writer is ready.";

    vm.hasFiles = false;
    vm.hasCurrentContent = false;
    vm.isCurrentRegistered = false;

      /////////////////////////////////////
     //  METHODS
    /////////////////////////////////////

    vm.init = function() {
      vm.loadAll();
    };

    vm.loadAll = function() {
      vm.fileslist = storageService.getFiles();
      vm.hasFiles = (vm.fileslist && vm.fileslist.length > 0) ? true : false;

      if(vm.hasFiles) {
        vm.message = {
          content: "You have <span class='badge'>"+vm.fileslist.length+"</span> registered writings.",
          type: "info"
        };
      } else {
        vm.message = {
          content: "There's no writings saved in your storage yet.",
          type: "info"
        };
      }
    };

    vm.load = function(name){
      modalService.target("open");
      modalService.setActive(false);

      if(storageService.checkExists(name)) {
        vm.current.name = name;
        vm.current.content = storageService.getFile(name);
        vm.hasCurrentContent = true;
        vm.isCurrentRegistered = true;

        vm.message = {
          content: "Your work '"+vm.current.name+"' was loaded.",
          type: "success"
        };
      } else {
        vm.message = {
          content: "There's no text '"+vm.current.name+"' in your local storage.",
          type: "alert"
        };
      }
    };

    vm.empty = function() {
      log("writer:::EMPTY");

      vm.current = {};
      vm.hasCurrentContent = false;
      vm.isCurrentRegistered = false;

      vm.message = {
        content: "Your writer is now clean and fresh.",
        type: "success"
      };

      $rootScope.$broadcast("empty_typezone");
      log("broadcast:::$rootScope.$broadcast('empty_typezone')");
    };

    vm.checkCurrent = function() {
      if(vm.hasCurrentContent) {
        vm.isCurrentRegistered = storageService.checkExists(vm.current.name);
      }
    };

    vm.open = function(){
      modalService.target("open");
      modalService.setActive(true);
    };

    vm.new = function(openModal) {
      log("writer:::NEW");

      vm.checkCurrent(); // Check if current is registered

      // Open dialog
      if(openModal && vm.hasCurrentContent) {
        modalService.target("new");
        modalService.setActive(true);

      } else if(vm.hasCurrentContent) {

        // Save and empty after that
        vm.save(true);

        // Close dialog
        modalService.target("new");
        modalService.setActive(false);
      } else {
        vm.message = {
          content: "The writer is empty. <a href='http://www.writersdigest.com/prompts' target='_blank'>Try a prompt ?</a>",
          type: "default"
        };
      }
    };

    vm.save = function(emptyAfterSave) {
      log("writer:::SAVE");

      if((vm.current.name && vm.current.name.length > 0) && (vm.current.content && vm.current.content.length > 0)) {
        storageService.saveFile(vm.current.name,vm.current.content,true);

        vm.message = {
          content: "Your text '"+vm.current.name+"' was saved.",
          type: "success"
        };

        emptyAfterSave ? vm.empty() : "";

      } else {
        vm.message = {
          content: "Your text must have a name and a content.",
          type: "warning"
        };
      }

    };


      /////////////////////////////////////
     //  EVENTS
    /////////////////////////////////////

    // Catch: Typing
    $scope.$watch("ctrl.current.content",function(){
      if(vm.current.content && vm.current.content.length > 0) {
        vm.hasCurrentContent = true;
      }
      log("watch:::vm.$watch('current.content')");
    });


      /////////////////////////////////////
     //  LAUNCH
    /////////////////////////////////////
    vm.init();

  }

})();
