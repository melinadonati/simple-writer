(function(){
  "use strict";

  var _PATH_ = "./modules/write/";

  angular.module('writer').directive('write',write);
  write.$inject = ["$rootScope"];

    /////////////////////////////////////
   //  Config
  /////////////////////////////////////
  function write($rootScope) {
    return {
      restrict: "E",
      scope: {
        content: "=content"
      },
      controller: writeModel,
      controllerAs: "write",
      templateUrl: _PATH_ + "write.tpl.html",
      link: writeView
    };
  }

    /////////////////////////////////////
   //  Control
  /////////////////////////////////////
  function writeModel() {
    var write = this;

    // Constants
    write._KEYS_ = [];
    for(var k = 97; k < 123; k++) {
      write._KEYS_.push(k);
    }
    write._KEY_ENTER_ = 13;
    write._LETTERS_ = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"];

    // Members
    write.sounds = {};
    write.sounds.alphabet = {};
    write.keys = {};
    write.keys.mapping = {};

    // Methods : ON / OFF
    write.on = function($scope) {
      $scope.sound = true;
    };
    write.off = function($scope) {
      $scope.sound = false;
    };

    // Method: LOAD SOUNDS
    write.sounds.load = function() {
      write._LETTERS_.forEach(function(letter, index, letters){
        write.sounds.alphabet[letter] = new buzz.sound(_PATH_ + "sounds/"+letter+".wav");
      });

      write.sounds.ding = new buzz.sound(_PATH_ + "sounds/ding.wav");
      write.sounds.type = new buzz.sound(_PATH_ + "sounds/type.wav");
      log("loaded:::write.sounds with HTML library buzz.js");
    };

    // Method: INIT KEYS MAPPING
    write.keys.init = function() {
      var letter, keycode, sound;

      for(var i = 0; i < write._LETTERS_.length; i++) {
        letter = write._LETTERS_[i];
        keycode = write._KEYS_[i];

        write.keys.mapping[keycode] = function() {
          write.sounds.alphabet[letter].stop().play();
          log("function:::write.sounds.alphabet["+letter+"].stop().play()");
        };
      }

      write.keys.mapping[write._KEY_ENTER_] = function() {
        write.sounds.ding.stop().play();
        log("function:::write.sounds.ding.stop().play()");
      };

      write.keys.mapping["default"] = function() {
        write.sounds.type.stop().play();
        log("function:::write.sounds.type.stop().play()");
      };
    };

    // Execution
    write.sounds.load();
    write.keys.init();
  }

    /////////////////////////////////////
   //  View
  /////////////////////////////////////
  function writeView(scope, element, attrs, controller) {

    var $typezone = $(element).find("[contenteditable]");

    $(element).on("keyup",function(){
      scope.content = $typezone.html();
      //log("keyup:::write_update --> scope.content");

      // Apply changes
      scope.$apply();
    });

    // Keypress
    scope.$watch("sound",function(soundValue){
      log("boolean:::hasSound === " + soundValue);
      if(soundValue) {
        $(element).on("keypress",typewriter);
        log("event:::bind:::keypress ---> typewriter sounds");
      } else {
        $(element).off("keypress");
        log("event:::unbind:::keypress ---> typewriter sounds");
      }
    });

    // Empty
    scope.$on("empty_typezone",function(){
      $typezone.html("");
    });

      /////////////////////////////////////
     //  Handler
    /////////////////////////////////////
    function typewriter(event) {
      var keycode = (event.keyCode ? event.keyCode : event.which);
      //log("event:::keycode === " + keycode);

      if(controller.keys.mapping[keycode]
          && typeof controller.keys.mapping[keycode] === "function") {
        controller.keys.mapping[keycode]();
      } else {
        controller.keys.mapping["default"]();
      }
    }

  }

})();
