(function(){
  "use strict";

  var _PATH_ = "./modules/modal/";

  angular.module('writer').directive('modal', modal);
  modal.$inject = ["modalService"];

    /////////////////////////////////////
   //  Config
  /////////////////////////////////////
  function modal(modalService) {
    return {
      restrict: "E",
      scope: {
        "alias": "@",
        "title": "@",
        "isClosable": "@",
        "isActive": "@"
      },
      transclude: true,
      controller: modalControl,
      controllerAs: "modal",
      templateUrl: _PATH_ + "modal.tpl.html",
      link: modalView
    };
  }

    /////////////////////////////////////
   //  Control
  /////////////////////////////////////
  function modalControl($scope,modalService) {
    var modal = this;

    modal.alias = $scope.alias ? $scope.alias : "";
    modal.title = $scope.title ? $scope.title : "";
    modal.content = $scope.content ? $scope.content : "";
    modal.isClosable = $scope.isClosable ? $scope.isClosable : true;
    modal.isActive = $scope.isActive ? $scope.isActive : false;

    modalService.add(modal);

    modal.open = function() {
      modal.isActive = true;
      log("toggle:::modal.open " + modal.alias);
    };
    modal.close = function() {
      modal.isActive = false;
      log("toggle:::modal.close " + modal.alias);
    };
  }

    /////////////////////////////////////
   //  View
  /////////////////////////////////////
  function modalView(scope, element, attrs, controller) {

    // Initialize content
    var initialContent = $(element).children(".modal-content").html();
    if(initialContent && initialContent.length > 0) {
      controller.content = initialContent;
    }

    scope.$on("modal$open",function(event,alias){
      if(alias === scope.alias) {
        controller.open();
        log("catch:::scope.$on('modal$open')");
      }
    });

    scope.$on("modal$close",function(event,alias){
      if(alias === scope.alias) {
        controller.close();
        log("catch:::scope.$on('modal$close')");
      }
    });
  }

})();
