(function(){
  "use strict";

  angular.module('writer').factory('modalService', modalService);
  modalService.$inject = ["$rootScope"];

    /////////////////////////////////////
   //  Instance
  /////////////////////////////////////
  function modalService($rootScope) {
    var service = {};

    service.modals = [];
    service.current = undefined;

    // Add
    service.add = function(modal){
      service.modals.push(modal);
      log("add:::modal to modalService", modal);
    };

    // Get
    service.get = function(alias){
      service.modals.forEach(function(modal,index,array){
        if(modal.alias === alias) {
          log("get:::modal by alias: " + alias, modal);
          return modal;
        }
      });
    };

    // Set current
    service.target =  function(alias){
      service.modals.forEach(function(modal,index,array){
        if(modal.alias === alias) {
          service.current = modal;
            log("set:::service.current: " + alias, modal);
        }
      });
    };

    // Transformers
    service.setTitle = function(text){
      service.current.title = text;
      $rootScope.$broadcast("modal$change_title");
      log("broadcast:::$rootScope --> 'modal$change_title' | value: " + text);
    };
    service.setContent = function(html){
      service.current.content = html;
      $rootScope.$broadcast("modal$change_content");
      log("broadcast:::$rootScope --> 'modal$change_content' | value: " + html);
    };
    service.setClosable = function(bool){
      service.current.isClosable = bool;
      $rootScope.$broadcast("modal$change_closable");
      log("broadcast:::$rootScope --> 'modal$change_closable' | value: " + bool);
    };
    service.setActive = function(bool){
      service.current.isActive = bool;
      bool ? $rootScope.$broadcast("modal$open",service.current.alias) : $rootScope.$broadcast("modal$close",service.current.alias);
      log("broadcast:::$rootScope --> is current modal active ?  | value: " + bool);
    };

    // Change
    service.change = function(alias,attributes,values){
      if(typeof attributes !== "array"
        || typeof values !== "array"
        || attributes.length !== values.length) {
          log("error:::Can't modify current modal with non array attributes and values or non matching length.")
          return;
      } else {
        service.target(alias); // target the modal
        for(var c = 0; c < attributes.length; c++) {
          var key = attributes[c];
          var value = values[c];
          service.current[key] = value; // change its values
          log("modify:::service.modal = " + alias,"---iteration","key: "+key+" ; value: "+value);
        }
        $rootScope.$broadcast("modal$changes");
        log("broadcast:::$rootScope --> 'modal$changes'");
      }
    };

    return service;
  }

})();
