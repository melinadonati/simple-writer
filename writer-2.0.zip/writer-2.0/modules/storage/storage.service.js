(function(){
  "use strict";

  angular.module('writer').factory('storageService', storageService);
  storageService.$inject = ["$rootScope"];

    /////////////////////////////////////
   //  Instance
  /////////////////////////////////////
  function storageService($rootScope) {
    var service = {};

    service._RESERVED_KEYS_ = [
      "music",
      "theme",
      "theme.style",
      "background",
      "background.style"
    ];

    service.encodeFileName = function(name) {
    	return encodeURI( name.replace(/'/g,'.').replace(/"/g,'::').replace(/ /g,'_') );
    }
    service.decodeFileName = function(name) {
    	return decodeURI( name ).replace(/\./g,"'").replace(/::/g,'"').replace(/_/g,' ');
    }

    service.checkExists = function(name) {
      if(localStorage.getItem(name)) {
        log("file_exists:::"+name);
        return true;
      }

      log("file_do_not_exists:::"+name);
      return false;
    };

    service.checkIsReservedKey = function(key) {
      return $.inArray(key, service._RESERVED_KEYS_);
    };

    service.getFiles = function() {
      if(localStorage.length > 0) {
        var textKeys = [];
        var localKeys = Object.keys(localStorage);

        localKeys.forEach(function(key,index,keys){
          if(service.checkIsReservedKey(key) == -1) {
            textKeys[textKeys.length] = key;
          }
        });
        $rootScope.$broadcast("storageService$filesLoaded");
        log("broadcast:::storageService$filesLoaded");

        return textKeys;
      }

      return false;
    };

    service.getFile = function(name){
      name = service.encodeFileName(name);
      if(localStorage.getItem(name)) {
        $rootScope.$broadcast("storageService$dataLoaded", name);
        log("broadcast:::storageService$dataLoaded --> name: "+name);

        return localStorage.getItem(name);
      }
  		return false;
    };

    service.saveFile = function(name,content,overwrite){
      name = service.encodeFileName(name);

      log("overwrite:::"+name+" === "+overwrite);
      overwrite = service.checkExists(name) ? overwrite : true;
      log("existing:::"+name+" === "+!overwrite);
      overwrite ? localStorage.setItem(name,content) : "";

      $rootScope.$broadcast("storageService$fileSaved");
      log("broadcast:::storageService$fileSaved");
      return overwrite;
    };

    return service;
  }

})();
