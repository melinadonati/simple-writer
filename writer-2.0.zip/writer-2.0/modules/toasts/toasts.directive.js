(function(){
  "use strict";

  var _PATH_ = "./modules/toasts/";

  angular.module('writer').directive('toasts',toasts);

    /////////////////////////////////////
   //  Config
  /////////////////////////////////////
  function toasts() {
    return {
      restrict: "E",
      scope: {
        "type": "=type",
        "message": "=message"
      },
      controller: toastsModel,
      controllerAs: "toasts",
      templateUrl: _PATH_ + "toasts.tpl.html",
      link: toastsView
    };
  }

    /////////////////////////////////////
   //  Control
  /////////////////////////////////////
  function toastsModel() {
    var toasts = this;
    toasts._TOAST_DURATION_ = 3000;
  }

    /////////////////////////////////////
   //  View
  /////////////////////////////////////
  function toastsView(scope, element, attrs, controller) {

    scope.$watch("message",function(newValue){
      if(newValue) {
        scope.type = scope.type ? scope.type : "info";

        var icon = "";
        switch(scope.type) {
          case "alert":
            icon = "mif-heart-broken";
            break;

          case "warning":
            icon = "mif-notification";
            break;

          case "success":
            icon = "mif-checkmark";
            break;

          case "info":
            icon = "mif-info";
            break;

          default:
            icon = "mif-pin fg-blue";
            break;
        }

        // Toast creation
        $(element).prepend("<div class='notify shadow "+scope.type+" padding20'><span class='notify-icon "+icon+"'></span><span class='notify-text'>"+newValue+"</span></div>");

        var $first = $(element).find(".notify").first();
        // Remove the message 3s later
        setTimeout(function(){
          $first.fadeOut(function(){
            $first.remove();

            scope.type = "";
            scope.message = "";
          });
        }, controller._TOAST_DURATION_);

        log("catch:::scope.$watch('message')");
      }
    });

  }

})();
