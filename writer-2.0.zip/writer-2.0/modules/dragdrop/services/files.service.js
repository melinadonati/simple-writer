(function(){
  "use strict";

  angular.module('writer').factory('filesService', filesService);
  filesService.$inject = ["$rootScope"];

    /////////////////////////////////////
   //  Instance
  function filesService($rootScope) {
    var service = {};

    // Tools
    var regex;
    var blackbox = {};

    // Constants
    service._MAX_SIZE_ = 10000000;
    service.__LABEL_START__ = "File: ";

    // Filetypes
    service._IMG_EXTENSION_  = [".jpg", ".jpeg", ".png", ".gif"];
    service._STYLE_EXTENSION_  = [".css"];

    // Messages
    service.__NO_FILE_FOUND__ = "No files detected.";
    service.__FILE_LOADED__ = "Your file has been uploaded.";
    service.__MAX_SIZE_REACHED__ = "You've reached the 10 Mo file size limit.";
    service._MSG_TYPES_ = {
      info: "info",
      success: "success",
      alert: "alert",
      failure: "failure",
    };


    // Members
    blackbox.files = undefined;
    blackbox.file = undefined;
    blackbox.filename = "";
    blackbox.filepath = "";
    blackbox.filelabel = "";

    // Reader
    service.reader = new FileReader();

    // Methods
    service.reset = function() {
      blackbox.files = undefined;
      blackbox.file = undefined;
      blackbox.filename = "";
      blackbox.filepath = "";
      blackbox.filelabel = "";

      $rootScope.$broadcast("filesService$reset");
      log("broadcast:::filesService$reset");
    };

    service.setFiles = function(files,success,failure) {
      if(files.length > 0) {
        blackbox.files = files;
        if( !service.setFile() ) {
          return false;
        }
        $rootScope.$broadcast("filesService$set_files",service);
        log("broadcast:::filesService$set_files");

        success && typeof success === "function" ? success.call() : "";

        return true;

      } else {
        $rootScope.$broadcast("filesService$message", [service.__NO_FILE_FOUND__, service._MSG_TYPES_.failure]);
        log("---message: "+service.__NO_FILE_FOUND__,"---type: "+service._MSG_TYPES_.failure,"broadcast:::filesService$message");

        failure && typeof failure === "function" ? failure.call() : "";

        return false;
      }
    };
    service.getFiles = function() {
      return blackbox.files;
    };

    service.setFile = function(file) {
      !file ? file = blackbox.files[0] : "";
      if(file.size >= service._MAX_SIZE_) {
        $rootScope.$broadcast("filesService$message", [service.__MAX_SIZE_REACHED__, service._MSG_TYPES_.alert]);
        log("---message: "+service.__MAX_SIZE_REACHED__,"---type: "+service._MSG_TYPES_.alert,"broadcast:::filesService$message");
        return false;
      }

      service.file = file;
      if(file.name.length > 0) {
        blackbox.file = file;
        blackbox.filename = file.name;
        blackbox.filelabel = service.__LABEL_START__ + file.name;
      }
      $rootScope.$broadcast("filesService$set_file",service);
      log("broadcast:::filesService$set_file");

      return true;
    };
    service.getFile = function() {
      return blackbox.file;
    };

    service.read = function(file) {
      !file ? file = blackbox.files[0] : "";
      service.reader.readAsDataURL(file);
    };
    service.reader.onloadend = function(event) {
      blackbox.filepath = event.target.result;

      $rootScope.$broadcast("filesService$read_file",service);
      log("broadcast:::filesService$read_file");

      $rootScope.$broadcast("filesService$message",[service.__FILE_LOADED__, service._MSG_TYPES_.success]);
      log("---message: "+service.__FILE_LOADED__,"---type: "+service._MSG_TYPES_.success,"broadcast:::filesService$message");
    };

    service.isFiletype = function(type) {
      var expected = [];
      var isType = false;

      switch(type) {
          case "image":
            expected = service._IMG_EXTENSION_;
            break;
          case "style":
            expected = service._STYLE_EXTENSION_;
            break;
          default:
            return false;
            break;
      }

      expected.forEach(function(extension, index, extensions){
        regex = new RegExp(extension+'$', "g");
        log(regex,"regex:::check file extension",blackbox.filename);
        if(regex.test(blackbox.filename)) {
          isType = true;
        }
      });

      return isType;
    };


    service.getFilepath = function() {
      return blackbox.filepath;
    };
    service.getFilename = function() {
      return blackbox.filename;
    };
    service.getFilelabel = function() {
      return blackbox.filelabel;
    };

    return service;
  }

})();
