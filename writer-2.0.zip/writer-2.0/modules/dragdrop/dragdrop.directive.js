(function(){
  "use strict";

  var _PATH_ = "./modules/dragdrop/";

  angular.module('writer').directive('dragdrop', dragdrop);
  dragdrop.$inject = ["filesService"];

    /////////////////////////////////////
   //  Config
  /////////////////////////////////////
  function dragdrop(filesService) {
    return {
      restrict: "E",
      scope: {},
      transclude: true,
      controller: dragdropControl,
      controllerAs: "dragdrop",
      templateUrl: _PATH_ + "dragdrop.tpl.html",
      link: dragdropView
    };
  }

    /////////////////////////////////////
   //  Control
  /////////////////////////////////////
  function dragdropControl($scope,filesService) {
    var dragdrop = this;

    dragdrop._MSG_DURATION_ = 3000;

    // Messages
    $scope.showMessage = false;
    $scope.message = {};
    $scope.message.class = "info";
    $scope.message.content = "";

    // File
    $scope.isLoading = false;
    $scope.showFile = false;
    $scope.filename = "";
    $scope.filepath = "";
    $scope.filelabel = "";

    // Filetypes
    $scope.is_image = false;
    $scope.is_style = false;
    $scope.fileType = "any";

    dragdrop.checkSetType = function(array) {
      array.forEach(function(filetype,index,filetypes){
        log("function:::checkSetType ---> "+filetype+" ? ","---iteration")
        if($scope.fileType === "any") {
          log("is:::$scope.fileType === 'any'");
          if(filesService.isFiletype(filetype)) {
            $scope.fileType = filetype;
            $scope["is_" + filetype] = true;
            log("set:::$scope.fileType = " + filetype);
            log("set:::$scope.is_" + filetype + " === true");
          } else {
            $scope.fileType = "any";
          }
        }
      });
    };

    // Events
    dragdrop.limitBubbling = function(event) {
      event.stopPropagation();
      event.preventDefault();
    };

    // DRAGGING
    dragdrop.drag = function(event) {
      dragdrop.limitBubbling(event);
    };

    // DROPPING
    dragdrop.drop = function(event) {
      dragdrop.limitBubbling(event);
      filesService.setFiles(event.target.files || event.dataTransfer.files, dragdrop.dropHandle, filesService.reset);
    };

    // HANDLERS
    dragdrop.dropHandle = function() {
      filesService.read();
    };
  }

    /////////////////////////////////////
   //  View
  /////////////////////////////////////
  function dragdropView(scope, element, attrs, controller) {

    // Dropzone
    var dropzone = $(element).find(".drop-zone").get(0);
    dropzone.addEventListener("dragenter",controller.drag,false);
    dropzone.addEventListener("dragexit",controller.drag,false);
    dropzone.addEventListener("dragover",controller.drag,false);
    dropzone.addEventListener("drop",controller.drop,false);

    scope.$on("filesService$set_files",function(){
      scope.isLoading = true;

      // Apply changes
      scope.$apply();
    });

    scope.$on("filesService$message",function(event,args){
      scope.showMessage = true;
      scope.message.class = args[1];
      scope.message.content = args[0];
      setTimeout(function() {
          scope.showMessage = false;
      }, controller._MSG_DURATION_);
      scope.showFile = (args[1] === "failure" || args[1] === "alert") ? false : true;
      scope.isLoading = false;

      // Apply changes
      scope.$apply();

      log("catch:::filesService$message --> dragdrop.showMessage = true");
    });

    scope.$on("filesService$read_file",function(event,service){
      controller.checkSetType(["image","style"]);

      scope.filepath = service.getFilepath();
      scope.filename = service.getFilename();
      scope.filelabel = service.getFilelabel();
      scope.showFile = true;
      scope.isLoading = false;

      // Apply changes
      scope.$apply();

      log("catch:::filesService$read_file --> dragdrop.showFile = true");
    });

    // Loading stop
    scope.$on("filesService$reset",function(){
        scope.isLoading = false;

        // Apply changes
        scope.$apply();

        log("catch:::filesService$reset --> dragdrop.isLoading = false");
    });

  }

})();
